/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.interfacesprogra;

/**
 *
 * @author andre
 */
class Cereal implements esAlimento, esDescuento {

    private final String tipoCereal;
    private final double precio;
    private final String caducidad;
    private final String marca;
    private final double descuento;

    public Cereal(String tipoCereal, double precio, String caducidad, String marca, double descuento) {
        this.tipoCereal = tipoCereal;
        this.precio = precio;
        this.caducidad = caducidad;
        this.marca = marca;
        this.descuento = descuento;
    }

    @Override
    public boolean esAlimento() {
        return true;
    }

    @Override
    public double Descuento() {
        return precio * (descuento / 100);
    }

    // Método personalizado para mostrar información completa del cereal
    public void mostrar() {
        System.out.println(" ");
        System.out.println("Cereal:");
        System.out.println("Tipo de cereal: " + tipoCereal);
        System.out.println("Precio: " + precio);
        System.out.println("Caducidad: " + caducidad);
        System.out.println("Marca: " + marca);
        System.out.println("¿Es alimento o es liquido? " + esAlimento());
        System.out.println("Descuento: " + Descuento() + "%");
    }
}
