/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.interfacesprogra;

/**
 *
 * @author andre
 */

class Detergente implements esLiquido, esDescuento {
    private final String marca;
    private final double precio;
    private final double volumen; // en litros
    private final String tipoEnvase;
    private final double descuento;

    public Detergente(String marca, double precio, double volumen, String tipoEnvase, double descuento) {
        this.marca = marca;
        this.precio = precio;
        this.volumen = volumen;
        this.tipoEnvase = tipoEnvase;
        this.descuento = descuento;
    }

    public boolean esLiquido() {
        return true;
    }

    public double Descuento() {
        return precio * (descuento / 100);
    }

    // Método personalizado para mostrar información completa del detergente
    public void mostrar() {
        System.out.println(" ");
        System.out.println("Detergente:");
        System.out.println("Marca: " + marca);
        System.out.println("Precio: " + precio);
        System.out.println("Volumen: " + volumen );
        System.out.println("Tipo de envase: " + tipoEnvase);
        System.out.println("El producto líquido? " + esLiquido());
        System.out.println("Descuento del producto: " + Descuento() + "%");
    }
}
