/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.interfacesprogra;

/**
 *
 * @author andre
 */
class Vino implements esLiquido, esDescuento {
    private final String marca;
    private final String tipo;
    private final double precio;
    private final double volumen;
    private final String tipoEnvase;
    private final String caducidad; 
    private final double descuento;

    public Vino(String marca, String tipo, double precio, double volumen, String tipoEnvase, String caducidad, double descuento) {
        this.marca = marca;
        this.tipo = tipo;
        this.precio = precio;
        this.volumen = volumen;
        this.tipoEnvase = tipoEnvase;
        this.caducidad = caducidad;
        this.descuento = descuento;
    }


    public boolean esLiquido() {
        return true;
    }

    
    public double Descuento() {
        return precio * (descuento / 100);
    }

    // Método personalizado para mostrar información completa del vino
    public void mostrar() {
        System.out.println(" ");
        System.out.println("Vino:");
        System.out.println("Marca: " + marca);
        System.out.println("Tipo: " + tipo);
        System.out.println("Precio: " + precio);
        System.out.println("Volumen: " + volumen + " litros");
        System.out.println("Tipo de envase: " + tipoEnvase);
        System.out.println("Caducidad: " + caducidad);
        System.out.println("El producto es alimento? " + esLiquido());
        System.out.println("Descuento: " + Descuento() + "%");
    }
}
