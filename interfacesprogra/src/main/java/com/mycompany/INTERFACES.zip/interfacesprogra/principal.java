/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.interfacesprogra;

/**
 *
 * @author andre
 *
 *
 */
public class principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Detergente detergente = new Detergente("Suavitel", 25, 2, "Botella", 10.0);
        detergente.mostrar();

        Cereal cereal = new Cereal("Tipo: Avena", 55.0, "02/05/2023", "Marca Zucaritas", 15.0);
        cereal.mostrar();

        Vino vino = new Vino("Torres ", "Tinto", 20.0, 0.50, "Botella", "03/08/2024", 5.0);
        vino.mostrar();
    }

   

}
